import numpy as np
import sklearn
import scipy.stats 

class SkewSet:
    def __init__(self):
        return

    def generate(self, n_samples=100, n_dim=1, n_cluster=4, random_state=42):

        parametre = {
            'mu' : np.random.uniform(-50, 50, size=(n_dim, n_cluster)),
            'sig' : np.random.uniform(0.5, 10., size=(n_dim, n_cluster)), 
            'nu' : np.random.uniform(1., 10., size=(n_dim, n_cluster)), 
            'lamb' : np.random.uniform(-5., 5., size=(n_dim, n_cluster)),
            'alpha' : np.full(n_cluster, 1.0 / n_cluster)
        }

        n = np.random.randint(1, n_samples, size=n_cluster) / n_samples

        # Listes pour stocker les résultats
        data = np.zeros((sum(n), 4))


        # Boucle sur chaque dimension
        n_tot = 0

        for i in range(len(n)):
            data[n_tot:n_tot+n[i], :] = (parametre['mu'][:, i] + 
                    parametre['sig'][:, i] * scipy.stats.skewnorm.rvs(a=parametre['lamb'][:, i], loc=0, scale=1, size=(n[i], n_dim), random_state=random_state) /
                    np.sqrt(scipy.stats.gamma.rvs(a=parametre['nu'][:, i]/2, scale=2/parametre['nu'][:, i], size=(n[i], n_dim), random_state=random_state)))
            n_tot += n[i]



        y_true = np.array([])
        for index, value in enumerate(n):
            y_true = np.append(y_true, (np.full(value, index)))

        data = sklearn.utils.shuffle(data, random_state=random_state)
        y_true = sklearn.utils.shuffle(y_true, random_state=random_state)


        return data, y_true

