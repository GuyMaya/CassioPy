## smm - Skew Mixture Model for clustering



## Installation

Install from Pypi using `pip` :

    $ pip install skew_mixture

## Documentation

